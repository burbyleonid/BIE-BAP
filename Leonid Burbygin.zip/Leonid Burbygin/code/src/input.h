#ifndef _Input_
#define _Input_

int initInput(char*);
int getChar(void);

#endif
