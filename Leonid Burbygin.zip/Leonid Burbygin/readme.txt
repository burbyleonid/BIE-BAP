To work with this repository you have to do the following steps:
1) Clone/download this repository
2) Manually change paths in main.cpp, they are marked as TODO
3) Use the command "make" to build the project
4) Use the command "./comp" to run my SMT solver on the test files

5) Use the command "./run_cvc5.sh" to run CVC5 solver on all tests (now 4 files)
6) Go to analysis.ipynb and compare results
